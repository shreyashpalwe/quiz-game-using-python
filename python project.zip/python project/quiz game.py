
yes = input("Do you want to start? (yes/no): ")

if yes == "yes":
    print("start")

score = 0

# Question 1
print("What is 2 + 2?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 4:
    score += 1

# Question 2
print("What is 8 * 2?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 16:
    score += 1

# Question 3
print("What is 16*3?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 48:
    score += 1

    # Question 4
print("What is 19-5?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 14:
    score += 1
    
      # Question 5
print("What is 94/2?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 47:
    score += 1
    
     # Question 6
print("What is 18+26?")
answer1 = int(input("Enter a number: ")) 

if answer1 == 44:
    score += 1
   
   
   
   
   
   
    print(f"Your score is {score}")







